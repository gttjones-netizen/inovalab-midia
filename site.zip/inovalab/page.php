<?php get_header();
while (have_posts()) { the_post();
    if (get_post_meta(get_the_ID(), 'il_raw', true)) {
        echo get_post_field('post_content', get_the_ID());
    } else { ?>
<section class="topo"><div class="wrap"><h1><?php the_title(); ?></h1></div></section>
<section class="bloco"><div class="wrap prosa"><?php the_content(); ?></div></section>
<?php }
}
get_footer();
