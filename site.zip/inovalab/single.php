<?php get_header();
while (have_posts()) { the_post(); ?>
<section class="topo"><div class="wrap">
<p class="migalha"><a href="/blog/">Blog</a></p>
<h1><?php the_title(); ?></h1>
<?php if (has_excerpt()) { ?><p class="lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php } ?>
<p class="assina">Por Eng. Civil Evanndro Resende, atualizado em <?php echo esc_html(get_the_modified_date('j \d\e F \d\e Y')); ?></p>
</div></section>
<section class="bloco"><div class="wrap prosa">
<?php echo get_post_meta(get_the_ID(), 'il_raw', true) ? get_post_field('post_content', get_the_ID()) : apply_filters('the_content', get_the_content()); ?>
<p class="cta"><?php echo il_wa_btn('Olá! Li o artigo "' . get_the_title() . '" no site e quero um orçamento de projeto.'); ?></p>
<p>Quer uma ideia de valor antes de conversar? Use a <a href="/calculadora-de-projetos/">calculadora de custo de projetos</a>.</p>
</div></section>
<?php }
get_footer();
