</main>
<footer class="carimbo"><div class="wrap"><img class="logo-rodape" src="<?php echo esc_url(get_theme_file_uri('assets/logo-h-branco.png')); ?>" alt="InovaLab" width="178" height="44" loading="lazy"><div class="selo">
<div class="c2"><b>Projetos estruturais, hidráulicos e elétricos em BIM</b></div>
<div><b>Responsável técnico</b><span>Eng. Civil Evanndro Resende</span></div>
<div><b>Base</b><span>Londrina, PR</span></div>
<div><b>Atendimento</b><span>Online, todo o Brasil</span></div>
<div><b>WhatsApp</b><span><a href="https://wa.me/5544997294406">(44) 99729-4406</a></span></div>
<div><b>Instagram</b><span><a href="https://www.instagram.com/inovalab_projetos/">@inovalab_projetos</a></span></div>
<div><b>Parceiros</b><span><a href="https://terceirize.eng.br">Terceirize</a></span></div>
</div></div></footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
