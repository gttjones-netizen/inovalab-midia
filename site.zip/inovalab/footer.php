</main>
<footer class="rodape"><div class="wrap">
<div class="cols">
<div><img src="<?php echo esc_url(get_theme_file_uri('assets/logo-h-branco.png')); ?>" alt="InovaLab" width="161" height="40" loading="lazy"><p>Projetos complementares em BIM para arquitetos, engenheiros e construtoras.</p><p>Responsável técnico: Eng. Civil Evanndro Resende</p></div>
<div><b>Projetos</b><a href="/projeto-estrutural/">Estrutural em concreto armado</a><a href="/projeto-de-fundacoes/">Fundações</a><a href="/projeto-de-protensao/">Protensão</a><a href="/projeto-de-estrutura-metalica/">Estrutura metálica</a><a href="/projeto-de-cobertura/">Coberturas</a><a href="/projeto-de-galpao/">Galpões</a><a href="/projeto-de-arquibancada/">Arquibancadas</a><a href="/projeto-de-piscina/">Piscinas</a><a href="/projeto-de-muro-de-arrimo/">Muros de arrimo</a><a href="/projeto-hidraulico/">Hidráulico</a><a href="/projeto-eletrico/">Elétrico</a><a href="/compatibilizacao-bim/">Compatibilização</a><a href="/modelagem-3d/">Modelagem BIM</a></div>
<div><b>Cidades</b><a href="/projeto-estrutural-londrina/">Londrina</a><a href="/projeto-estrutural-maringa/">Maringá</a><a href="/projeto-estrutural-jundiai/">Jundiaí</a><a href="/projeto-estrutural-assis/">Assis</a></div>
<div><b>Contato</b><a href="https://wa.me/5544997294406">WhatsApp (44) 99729-4406</a><a href="https://www.instagram.com/inovalab_projetos/">Instagram</a><a href="https://www.youtube.com/@inovalab_projetos">YouTube</a><a href="/blog/">Blog</a><a href="https://terceirize.eng.br">Terceirize, para engenheiros</a></div>
</div>
<p class="fim">InovaLab Projetos. Londrina, PR. Atendimento online em todo o Brasil. <a href="/politica-de-privacidade/" style="display:inline">Política de privacidade</a></p>
</div></footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
