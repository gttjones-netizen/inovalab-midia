<?php
if (!defined('ABSPATH')) exit;
define('IL_WA', 'https://wa.me/5544997294406');

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('html5', array('style', 'script', 'search-form'));
});

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('il-fonts', 'https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600&family=Barlow+Condensed:wght@500;600&display=swap', array(), null);
    wp_enqueue_style('il', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');
}, 20);

function il_ctx_id() {
    if (is_home()) return (int) get_option('page_for_posts');
    if (is_singular()) return (int) get_queried_object_id();
    return 0;
}
function il_meta($key) {
    $id = il_ctx_id();
    return $id ? (string) get_post_meta($id, $key, true) : '';
}

add_filter('pre_get_document_title', function ($t) {
    $m = il_meta('il_seo_title');
    return $m !== '' ? $m : $t;
});

add_action('wp_head', function () {
    $desc = il_meta('il_seo_desc');
    $title = wp_get_document_title();
    $url = is_front_page() ? home_url('/') : (il_ctx_id() ? get_permalink(il_ctx_id()) : home_url('/'));
    echo '<link rel="icon" type="image/png" href="' . esc_url(get_theme_file_uri('assets/icone.png')) . '">' . "\n";
    if ($desc !== '') echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:site_name" content="InovaLab Projetos">' . "\n";
    echo '<meta property="og:locale" content="pt_BR">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
    if ($desc !== '') echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url(get_theme_file_uri('assets/icone.png')) . '">' . "\n";
    if (is_front_page()) {
        $ld = array(
            '@context' => 'https://schema.org',
            '@type' => 'ProfessionalService',
            'name' => 'InovaLab Projetos',
            'description' => 'Projetos estruturais, hidráulicos e elétricos em BIM para casas e edificações de até três pavimentos.',
            'url' => home_url('/'),
            'logo' => get_theme_file_uri('assets/icone.png'),
            'telephone' => '+55 44 99729-4406',
            'email' => 'gttjones@gmail.com',
            'areaServed' => array('@type' => 'Country', 'name' => 'Brasil'),
            'address' => array('@type' => 'PostalAddress', 'addressLocality' => 'Londrina', 'addressRegion' => 'PR', 'addressCountry' => 'BR'),
            'founder' => array('@type' => 'Person', 'name' => 'Evanndro Resende', 'jobTitle' => 'Engenheiro Civil'),
            'priceRange' => 'R$ 5 a R$ 20 por m²',
            'sameAs' => array('https://www.instagram.com/inovalab_projetos/', 'https://www.youtube.com/@inovalab_projetos', 'https://www.linkedin.com/in/evanndroresende'),
        );
        echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
    if (is_singular('post')) {
        $p = get_queried_object();
        $ld = array(
            '@context' => 'https://schema.org', '@type' => 'Article',
            'headline' => get_the_title($p), 'description' => $desc,
            'datePublished' => get_the_date('c', $p), 'dateModified' => get_the_modified_date('c', $p),
            'author' => array('@type' => 'Person', 'name' => 'Evanndro Resende', 'jobTitle' => 'Engenheiro Civil'),
            'publisher' => array('@type' => 'Organization', 'name' => 'InovaLab Projetos'),
            'mainEntityOfPage' => get_permalink($p),
        );
        echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
}, 2);

function il_wa_btn($msg, $label = 'Pedir orçamento no WhatsApp') {
    $icon = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.600 15.100L2 22l5-1.300A10 10 0 1 0 12 2Zm0 18.200a8.200 8.200 0 0 1-4.200-1.150l-.300-.180-3 .780.800-2.900-.200-.300A8.200 8.200 0 1 1 12 20.200Z"/></svg>';
    return '<a class="btn" href="' . esc_url(IL_WA . '?text=' . rawurlencode($msg)) . '">' . $icon . '<span>' . esc_html($label) . '</span></a>';
}
