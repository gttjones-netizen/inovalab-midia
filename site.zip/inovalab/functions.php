<?php
if (!defined('ABSPATH')) exit;
define('IL_WA', 'https://wa.me/5544997294406');

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('html5', array('style', 'script', 'search-form'));
});

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('il-fonts', 'https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;600;700;800&display=swap', array(), null);
    wp_enqueue_style('il', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');
}, 20);

function il_ctx_id() {
    if (is_home()) return (int) get_option('page_for_posts');
    if (is_singular()) return (int) get_queried_object_id();
    return 0;
}
function il_meta($key) {
    $id = il_ctx_id();
    return $id ? (string) get_post_meta($id, $key, true) : '';
}

add_filter('pre_get_document_title', function ($t) {
    $m = il_meta('il_seo_title');
    return $m !== '' ? $m : $t;
});

add_action('wp_head', function () {
    $desc = il_meta('il_seo_desc');
    $title = wp_get_document_title();
    $url = is_front_page() ? home_url('/') : (il_ctx_id() ? get_permalink(il_ctx_id()) : home_url('/'));
    echo '<link rel="icon" type="image/png" href="' . esc_url(get_theme_file_uri('assets/icone.png')) . '">' . "\n";
    if ($desc !== '') echo '<meta name="description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<meta property="og:type" content="' . (is_singular('post') ? 'article' : 'website') . '">' . "\n";
    echo '<meta property="og:site_name" content="InovaLab Projetos">' . "\n";
    echo '<meta property="og:locale" content="pt_BR">' . "\n";
    echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
    if ($desc !== '') echo '<meta property="og:description" content="' . esc_attr($desc) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
    echo '<meta property="og:image" content="' . esc_url(get_theme_file_uri('assets/icone.png')) . '">' . "\n";
    if (is_front_page()) {
        $ld = array(
            '@context' => 'https://schema.org',
            '@type' => 'ProfessionalService',
            'name' => 'InovaLab Projetos',
            'description' => 'Projetos estruturais, hidráulicos e elétricos em BIM para casas e edificações de até três pavimentos.',
            'url' => home_url('/'),
            'logo' => get_theme_file_uri('assets/icone.png'),
            'telephone' => '+55 44 99729-4406',
            'email' => 'gttjones@gmail.com',
            'areaServed' => array('@type' => 'Country', 'name' => 'Brasil'),
            'address' => array('@type' => 'PostalAddress', 'addressLocality' => 'Londrina', 'addressRegion' => 'PR', 'addressCountry' => 'BR'),
            'founder' => array('@type' => 'Person', 'name' => 'Evanndro Resende', 'jobTitle' => 'Engenheiro Civil'),
            'priceRange' => 'R$ 5 a R$ 20 por m²',
            'sameAs' => array('https://www.instagram.com/inovalab_projetos/', 'https://www.youtube.com/@inovalab_projetos', 'https://www.linkedin.com/in/evanndroresende'),
        );
        echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
    if (is_singular('post')) {
        $p = get_queried_object();
        $ld = array(
            '@context' => 'https://schema.org', '@type' => 'Article',
            'headline' => get_the_title($p), 'description' => $desc,
            'datePublished' => get_the_date('c', $p), 'dateModified' => get_the_modified_date('c', $p),
            'author' => array('@type' => 'Person', 'name' => 'Evanndro Resende', 'jobTitle' => 'Engenheiro Civil'),
            'publisher' => array('@type' => 'Organization', 'name' => 'InovaLab Projetos'),
            'mainEntityOfPage' => get_permalink($p),
        );
        echo '<script type="application/ld+json">' . wp_json_encode($ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
}, 2);

function il_wa_btn($msg, $label = 'Pedir orçamento no WhatsApp') {
    $icon = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.600 15.100L2 22l5-1.300A10 10 0 1 0 12 2Zm0 18.200a8.200 8.200 0 0 1-4.200-1.150l-.300-.180-3 .780.800-2.900-.200-.300A8.200 8.200 0 1 1 12 20.200Z"/></svg>';
    return '<a class="btn" href="' . esc_url(IL_WA . '?text=' . rawurlencode($msg)) . '">' . $icon . '<span>' . esc_html($label) . '</span></a>';
}

define('IL_GA4', 'G-16JVS12TVW');
define('IL_PIXEL', '611176184972350');

/* Rastreamento só depois do consentimento (LGPD). */
add_action('wp_footer', function () { ?>
<div id="il-consent" class="il-consent" hidden role="dialog" aria-label="Privacidade">
<p>Uso cookies para medir as visitas e melhorar o site. Você pode aceitar ou recusar. <a href="/politica-de-privacidade/">Política de privacidade</a></p>
<div><button type="button" data-c="0">Recusar</button><button type="button" data-c="1" class="ok">Aceitar</button></div>
</div>
<script>
(function(){
var GA='<?php echo esc_js(IL_GA4); ?>',PX='<?php echo esc_js(IL_PIXEL); ?>',K='il_consent',on=false;
window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments);};
function get(){try{return localStorage.getItem(K);}catch(e){return null;}}
function set(v){try{localStorage.setItem(K,v);}catch(e){}}
function load(){if(on)return;on=true;
 var s=document.createElement('script');s.async=true;s.src='https://www.googletagmanager.com/gtag/js?id='+GA;document.head.appendChild(s);
 gtag('js',new Date());gtag('config',GA);
 !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
 fbq('init',PX);fbq('track','PageView');}
var box=document.getElementById('il-consent'),c=get();
if(c==='1')load();else if(c!=='0')box.hidden=false;
box.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;set(b.dataset.c);box.hidden=true;if(b.dataset.c==='1')load();});
document.addEventListener('click',function(e){var a=e.target.closest('a[href*="wa.me"]');if(!a||!on)return;
 gtag('event','generate_lead',{method:'whatsapp',page_path:location.pathname});if(window.fbq)fbq('track','Contact');});
var calc=document.getElementById('ilcalc'),used=false;
if(calc)calc.addEventListener('input',function(){if(used||!on)return;used=true;gtag('event','calculadora_uso');});
})();
</script>
<?php }, 20);
