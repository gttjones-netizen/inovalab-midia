<?php get_header(); ?>
<section class="topo"><div class="wrap">
<h1><?php echo is_home() ? 'Blog da InovaLab' : (is_404() ? 'Página não encontrada' : esc_html(wp_get_document_title())); ?></h1>
<?php if (is_home()) { ?><p class="lead">O que eu gostaria que todo mundo soubesse antes de construir: fundação, estrutura, custos e projeto em BIM, explicados por quem calcula.</p><?php } ?>
</div></section>
<section class="bloco"><div class="wrap">
<?php if (have_posts()) { ?><div class="quadro posts"><?php while (have_posts()) { the_post(); ?>
<a href="<?php the_permalink(); ?>"><h3><?php the_title(); ?></h3><p><?php echo esc_html(get_the_excerpt()); ?></p><span>Ler artigo</span></a>
<?php } ?></div>
<?php the_posts_pagination(array('prev_text' => 'Anteriores', 'next_text' => 'Próximos'));
} else { ?><p>Não encontrei o que você procurava. Volte para a <a href="/">página inicial</a> ou use a <a href="/calculadora-de-projetos/">calculadora de projetos</a>.</p><?php } ?>
</div></section>
<?php get_footer();
