<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="il">
<header class="cab"><div class="wrap cab-in">
<a class="marca" href="<?php echo esc_url(home_url('/')); ?>" aria-label="InovaLab, página inicial"><img src="<?php echo esc_url(get_theme_file_uri('assets/logo-h.png')); ?>" alt="InovaLab" width="170" height="42"></a>
<nav aria-label="Principal"><a href="/projetos/">Projetos</a><a href="/portfolio/">Portfólio</a><a href="/calculadora-de-projetos/">Estimativa</a><a href="/blog/">Blog</a><a class="pill" href="/contato/">Contato</a></nav>
</div></header>
<main>
