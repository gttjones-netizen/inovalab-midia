<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div class="il">
<header class="cab"><div class="wrap cab-in">
<a class="marca" href="<?php echo esc_url(home_url('/')); ?>" aria-label="InovaLab, página inicial"><img src="<?php echo esc_url(get_theme_file_uri('assets/logo-h.png')); ?>" alt="InovaLab" width="161" height="40"></a>
<nav aria-label="Principal"><a href="/projeto-estrutural/">Estrutural</a><a href="/projeto-hidraulico/">Hidráulico</a><a href="/projeto-eletrico/">Elétrico</a><a href="/calculadora-de-projetos/">Calculadora</a><a href="/blog/">Blog</a><a href="/contato/">Contato</a></nav>
</div></header>
<main>
